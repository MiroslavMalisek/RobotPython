# tools useful for a robot which would like to use a camera to follow a
# line

import numpy as np
import cv2
import math
import os
import sys
sys.path.append('./python_code')

class LineDetection:

  def __init__(self):
    #definir main colors como variables "globales"
    self.blue = (255, 0, 0)
    self.green = (0, 255, 0)
    self.red = (0, 0, 255)
    self.white = (255, 255, 255)
    self.black = (0, 0, 0)

    self.im_dim = [320, 240] #dimensiones de la imagen original

    # vamos a trabajar con la mitad inferior de la imagen, definimos las dimensiones (rectángulo)
    self.ROI_start_x = 0
    self.ROI_start_y = 80
    self.ROI_end_x = self.im_dim[0]
    self.ROI_end_y = self.im_dim[1]
    # self.ROI_start = (ROI_start_x, ROI_start_y)
    # self.ROI_end = (ROI_end_x, ROI_end_y)

    self.im_dim_ROI = [320, 160]

    #definir el punto en el centro y abajo de la imagen
    self.centro_entrada = np.array([int(self.im_dim_ROI[0]/2), int(self.im_dim_ROI[1])])
    #definir el punto en el centro y arriba de la imagen
    self.centro_salida = np.array([int(self.im_dim_ROI[0]/2), 0])
    #definir el punto en el centro de la imagen
    self.punto_central = np.array([int(self.centro_entrada[0]), int(self.centro_entrada[1]/2)])

    #variable para almacenar el numero de defectos de la línea en la imagen previa
    self.n_defectos_prev = 0

    #variable que va a contar cuantos frames uno detras del otro tienen el mismo numero de defectos
    self.n_frames = 0

    #variable que controla si el robot esta en un cruce
    self.cruce = False
    #variable que dice si la flecha ha sido analizada en el cruce
    self.flecha_analizada = False

    #variable que almacena el numero de areas negras en la imagen previa
    self.negras_prev = 1

    #variable que va almacenar el punto de salida del frame anterior, por defecto centro y arriba
    self.salida_prev = np.array([int(self.im_dim[0]/2), 0])

    #variable que controla si en el frame actual se encuntra la línea
    self.foundLine = False

    #variable que almacena la velocidad maximal del robot
    self.rangoMax = 1

    #variable que dice si se ha encontrado centro de defectos
    self.centro_def_enc = False




    #--------------------------------------------------------------------------------
    #               entrenamiento de marcas

    # almacenar las coordenadas de la fila suprior de la imagen
    self.points_borde_arriba = []
    for i in range(self.im_dim_ROI[0]):
        point = (i, 0)
        self.points_borde_arriba.append(point)

    # almacenar las coordenadas de la fila inferior de la imagen
    self.points_borde_abajo = []
    for i in range(self.im_dim_ROI[0]):
        point = (i, int(self.im_dim_ROI[1]) - 1)
        self.points_borde_abajo.append(point)

    #variables que dicen si la marca se encuntra en el borde superior o inferior
    self.marca_borde_arriba = False
    self.marca_borde_abajo = False

    # obtener la lista de contours de imagenes de entrenamiento de marcas
    #usamos el conjunto de entrenamiento proporcionado en el moodle (27 imagenes)
    path = '/home/robotica/pyrobot/tools/marcas-capturasStage/'
    self.etiquetas_marcas = []
    self.contours_marcas = []
    # recorremos todos los ficheros en la carpeta con los imagenes
    #i = 0
    for root, dirs, files in os.walk(path):
        my_key = os.path.basename(root)
        for file_ in files:
            full_file_path = os.path.join(root, file_)
            img_marca = cv2.imread(full_file_path)
            img_marca = cv2.cvtColor(img_marca, cv2.COLOR_BGR2RGB)
            #img_marca = cv2.GaussianBlur(img_marca, (3, 3), 0)
            # etiqutar los imagenes segun el nombre del fichero
            if "woman" in file_:
                self.etiquetas_marcas.append(3)
            elif "stairs" in file_:
                self.etiquetas_marcas.append(1)
            elif "telephone" in file_:
                self.etiquetas_marcas.append(2)
            elif "man" in file_:
                self.etiquetas_marcas.append(0)

            #escalamos la marca
            img_marca = self.normalize_filled(img_marca, (255, 0, 0))
            linImgRed = np.all(img_marca == (255, 0, 0), axis=2).astype(np.uint8) * 255
            # encontrar contours de las marcas
            contListRed, hierarchy = cv2.findContours(linImgRed, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
            # guardarlos en una lista
            #cv2.imshow("marca" + str(i), img_marca)
            #i = i + 1
            self.contours_marcas.append(contListRed[0])
    self.etiquetas_marcas = np.array(self.etiquetas_marcas)
    self.contours_marcas = np.array(self.contours_marcas)

  # funcion para ajustar la marca a un tamano predefinido
  def normalize_filled(self, img, color):
        # img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        linImgRed = np.all(img == color, axis=2).astype(np.uint8) * 255
        contListRed, hierarchy = cv2.findContours(linImgRed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        # fill shape
        # cv2.fillPoly(img, pts=contListRed, color=(255, 255, 255))
        bounding_rect = cv2.boundingRect(contListRed[0])
        img_cropped_bounding_rect = img[bounding_rect[1]:bounding_rect[1] + bounding_rect[3],
                                    bounding_rect[0]:bounding_rect[0] + bounding_rect[2]]
        # resize all to same size
        img_resized = cv2.resize(img_cropped_bounding_rect, (300, 300))
        return img_resized

  # funcion que calcula la similitud entre los imagenes de entrenamiento y el objeto en el video
  def detectar_marca(self, marca):
      resultados = []
      for i in range(len(self.contours_marcas)):
          d1 = cv2.matchShapes(marca, self.contours_marcas[i], 2, 0.0)
          resultados.append(d1)
      # elegir el valor minimo que deberia corresponder con la imagen de entrenamiento
      resultado = np.argmin(resultados)
      # obtener la clase de la marca predicha
      clase = self.etiquetas_marcas[resultado]
      if clase == 0:
          return "man"
      elif clase == 1:
          return "stairs"
      elif clase == 2:
          return "telephone"
      elif clase == 3:
          return "woman"

  def find_nearest(self, array, value):
    array = np.asarray(array)
    return (np.abs(array - value)).argmin()

  #funcion que normaliza la imagen de entrada
  def norm_RGB(self, imagen):
    img_norm = imagen / (np.sum(imagen, axis=2)[:, :, np.newaxis])  # divide every pixel by sum of the three pixels
    return img_norm

  # funcion que ajusta el tamano del angulo en un rango -1, 1 (para obtener un valor de giro)
  def map_pos(self, angle):
    return (angle + 90) * (1 + 1) / (90 + 90) - 1

  # funcion que ajusta el tamano del angulo en un rango 0, rangoMax (para obtener un valor de velocidad)
  def map_vel(self, angle):
    return (abs(angle) - 90) * (self.rangoMax - 0) / (0 - 90) + 0


#-----------------------------------------------------------------------------------------
  #             metodo principal

  def findLineDeviation(self, frame):
    fr = frame.copy()
    # seleccionar la mitad de abajo del frame
    frame = frame[self.ROI_start_y:self.ROI_end_y, :, :]

    #extraemos las conturas de marcas antes de aplicar smoothing
    imgRedMarca = np.all(frame == self.red, axis=2).astype(np.uint8) * 255
    contListRedMarca, hierarchyMarca = cv2.findContours(imgRedMarca, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    #if len(contListRedMarca) > 1:
        #contListRedMarca = max(contListRedMarca,key=len)
    #print(len(contListRedMarca))
    #cv2.drawContours(frame, contListRedMarca, -1, self.green, 2)
    frameMarca = frame.copy()

    #smoothing (principalmente a causa de la linea)
    frame = cv2.GaussianBlur(frame, (5, 5), 0)



    # ------------------------------------------------------------------------------------------------------
    #                   segmentacion

    # crear array de etiquetas - meter 0 en las posiciones donde los pixeles de las imagen de la camara son azules
    # meter 1 en las posiciones donde los pixeles de la imagen de la camara son rojos
    # meter 2 en las posiciones donde los pixeles de las imagenes etiquetadas son de otra combinacion de colores (fondo)

    etiquetas = np.select([np.all(frame == self.blue, axis=2), np.all(frame == self.red, axis=2)],
                          [0, 1],
                          default=2)

    # cambiar cada pixel del frame a uno de los tres colores segun la etiqueta (color)
    frame[etiquetas == 0] = self.blue
    frame[etiquetas == 1] = self.red
    frame[etiquetas == 2] = self.black

    # numero de areas negras (fondo)
    linImg = np.all(frame == self.black, axis=2).astype(np.uint8) * 255
    contList, hierarchy = cv2.findContours(linImg, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    negras = 0
    for i in range (len(contList)):
        if cv2.contourArea(contList[i]) > 100:
            negras = negras + 1

    # -----------------------------------------------------------------------------------------------------
    #           bordes

    # crear una copia de la imagen etiqutada donde la informacion aparece solamente en el borde de la imagen etiqutada
    frame_borders = frame.copy()
    frame_borders[10:-10, 10:-10] = self.black

    # detectar contours  azules en los bordes de la imagen etiquetada
    linImg = np.all(frame_borders == self.blue, axis=2).astype(np.uint8) * 255
    contList, hierarchy = cv2.findContours(linImg, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
    lenContList = len(contList)

    #consideramos que se ha encontrado la linea si aparecen al menos 2 trozos azules en los bordes
    #si apaerece una, no hay salida
    #si cero, no hay entrada ni salida
    if (lenContList == 0) or (lenContList == 1):
        self.foundLine = False
        cv2.imshow("Vision", frame)
        cv2.waitKey(1)
        #el roboť va adelante
        #print(self.foundLine)
        return self.foundLine, 0, 0.5
    else:
        self.foundLine = True

    ##calcumas el centro de las masas de contoured objetos en los bordes
    distancias_entrada = []
    distancias_salida = []
    points = []
    for i in range(len(contList)):
      area = cv2.contourArea(contList[i])
      # elegir solamente los objetos mas grandes (evitar que se conten los pequenos fallos en la segmentacion)
      # y tambien para poder obtener centro de masas
      if area > 10:
        M = cv2.moments(contList[i])
        cX = int(M["m10"] / M["m00"])
        cY = int(M["m01"] / M["m00"])
        # guardamos la coordenada Y
        distancias_entrada.append(cY)
        if (self.cruce is False) or ((self.cruce is True) and (self.flecha_analizada is False)):
          # si el robot no esta en el cruce o esta pero no habia analizado la marca
          # se calcula la distancia entre el centro de arriba y los centros de masas
          distancias_salida.append(np.linalg.norm(np.array([cX, cY]) - self.centro_salida))
        else:
          # si esta en el cruce y ya habia analizado la flecha
          #se calcula la distancia entre los centros de masas y el punto de salida en el paso anterior
          #(queremos seguir la misma salida hasta salir de la cruce)
          distancias_salida.append(np.linalg.norm(np.array([cX, cY]) - self.salida_prev))
        points.append(np.array([cX, cY]))

    # la entrada será el punto más inferior de la imagen (coordenada Y maxima)
    if(distancias_entrada == 1):
        entrada_index = distancias_entrada
    else:
        entrada_index = np.argmax(distancias_entrada)
    entrada = points[entrada_index]
    # queremos que la entrada será lo más en el centro posible
    if (entrada[0] < self.centro_entrada[0] - 30) or (entrada[0] > self.centro_entrada[0] + 30) or (entrada[1] < self.centro_entrada[1] - 30):
      entrada = self.centro_entrada
    # borramos el punto de entrada de point y salidas para asegurarse que no sean iguales que la entrada
    points.pop(entrada_index)
    distancias_salida.pop(entrada_index)
    #print(entrada)
    #print(distancias_salida)

    # seleccionamos el punto mas cercano al punto central de arriba
    # como hemos borrado el punto de entrada de la lista, hay que comprobar el numero de puntos restantes
    if len(points) == 0:
        #no hay salida en la imagen actual
        self.foundLine = False
        cv2.imshow("Vision", frame)
        cv2.waitKey(1)
        # el robot va adelante
        return self.foundLine, 0, 1.0
    if len(points) == 1:
      salida = points[0]
    else:
      #print(self.foundLine)
      salida = points[np.argmin(distancias_salida)]

    """
    # dibujar el punto de entrada
    cv2.circle(frame_borders, (entrada[0], entrada[1]), 10, (255, 255, 0), -1)
    # dibujar el punto de salida
    cv2.circle(frame_borders, (salida[0], salida[1]), 10, (0, 255, 255), -1)
    cv2.imshow('frame_borders_ent_sal', frame_borders)
    """

    # ------------------------------------------------------------------------------------------------------
    #               convexity defects

    # detectar contours azules en toda la imagen etiquetada
    linImg = np.all(frame == self.blue, axis=2).astype(np.uint8) * 255
    contList, hierarchy = cv2.findContours(linImg, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
    cv2.drawContours(frame, contList, -1, self.white, 1)

    # como la linea deberia formar una unica contura, vamos a trbajar con contList[0]
    cnt = contList[0]
    # construimos convex hull para contours encontrados
    hull = cv2.convexHull(cnt, returnPoints=False)
    defects = cv2.convexityDefects(cnt, hull)
    n_defects = 0
    defects_coord = []
    # asegurarse que hay algun defecto (agujero) para que no ponga error
    if type(defects) != type(None):
      # recorrer todos los defectos (agujeros)
      for i in range(defects.shape[0]):
        s, e, f, d = defects[i, 0]
        #start = tuple(cnt[s, 0])
        #end = tuple(cnt[e, 0])
        far = tuple(cnt[f, 0])
        # elegir solo los que tienen la longitud mayor que 2000
        if d > 2000:
          cv2.circle(frame, far, 5, self.green, -1)
          #acumular el numero de defectos
          n_defects = n_defects + 1
          # guardar la posicion del defecto
          defects_coord.append(far)
    # calcular el centro de puntos de defectos si aparecen al menos 2
    if (len(defects_coord)) > 1:
      self.centro_def_enc = True
      centro_defects = np.mean(defects_coord, axis=0, dtype=np.int32)
      # dibujar el punto central de defectos
      cv2.circle(frame, (centro_defects[0], centro_defects[1]), 5, self.white, -1)
    else:
        self.centro_def_enc = False
    defects_coord.clear()



    #------------------------------------------------------------------------------------------------------
    #                   cruce y flecha

    #estamos en un cruce si el numero de areas negras es mayor que 2
    if (self.negras_prev > 2) and (negras > 2):
        self.n_frames = self.n_frames + 1
        #si hay el numero mayor que 2 en 3 frames sin cambios, estamos en un cruce
        if (self.n_frames == 3) and (self.cruce is False):
            self.cruce = True
    #por otro lado, salimos del cruce si al menos en tres frames uno detras del otro aparece un numero
    #de areas negras menor o igual que 2
    elif (self.negras_prev <= 2) and (negras <= 2):
        self.n_frames = self.n_frames + 1
        if (self.n_frames == 3) and (self.cruce is True):
            #salimos de la cruce
            self.cruce = False
            self.flecha_analizada = False
    # si el numero de defectos ha cambiado respeto al previo, no estamos de una manera estable en la cruce
    else:
        self.n_frames = 0

    #si estamos en un cruce y todavía no se ha anlizado la flecha, la analizamos
    if self.cruce is True and self.flecha_analizada is False:
        #estamos en el cruce, pero la flecha no ha sido analizada, el robot debe ir lentamente
        self.rangoMax = 0.2
        #contours de la flecha (marca roja en el cruce)
        linImgRed = np.all(frame == self.red, axis=2).astype(np.uint8)*255
        contListRed, hierarchy = cv2.findContours(linImgRed,cv2.RETR_LIST,cv2.CHAIN_APPROX_NONE)
        #asegurarse que se ha detectado algun objeto
        if (len(contListRed) > 0) and (cv2.contourArea(contListRed[0]) > 10):
            #calcular el centro de la flecha
            M = cv2.moments(contListRed[0])
            cX = int(M["m10"] / M["m00"])
            cY = int(M["m01"] / M["m00"])
            if (cY >= int(self.im_dim_ROI[1]/2)) or ((self.centro_def_enc is True) and centro_defects[1] >= int(self.im_dim_ROI[1]/2)):
                #si el centro de la flecha o el centro de defectos de la cruce está en la mitad inferior de la imagen, analizamos su angulo y indicamos que se ha analizado
                self.flecha_analizada = True
                #print("fkecha", self.flecha_analizada)
                cv2.circle(frame, (cX, cY), 10, (255, 255, 0), -1)
                #el metodo fitEllipse necesita al menos 5 puntos
                if len(contListRed[0]) > 4:
                    ellipse = cv2.fitEllipse(contListRed[0])
                    angleFlecha = ellipse[2]
                    #if angleFlecha > 90:
                        #ajustar el valor del angulo para que coincidan las magnitudes con los angulos calculados entre centro y bordes
                        #angleFlecha = angleFlecha - 90
                    #else:
                        #angleFlecha = -1*angleFlecha
                #el punto de salida sera uno de los puntos en el borde cuyo angulo con el centro de las masas de la flecha
                # tiene la menor diferencia con el angulo de la flecha

                #calcular el angulo entre el centro de las masas de la flecha y los centros de masas de los trozos de linea en los bordes (excepto entrada)
                angulos_centro_points = []
                for point in points:
                    #usamos la funcion atan para dos puntos
                    angulo = -1*int(math.degrees(math.atan2((centro_defects[0] - point[0]), (centro_defects[1] - point[1]))))
                    angulos_centro_points.append(angulo)

                #print("angulos", angulos_centro_points)
                #encontramos el angulo que es mas parecido al angulo de la elipsis que rodea la flecha
                salida = points[self.find_nearest(angulos_centro_points, angleFlecha)]
                cv2.putText(frame, "Angle flecha " + str(angleFlecha), (20, 40),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, self.red, 2)
                cv2.ellipse(frame, ellipse, self.white, 2)
                cv2.drawContours(frame, contList, -1, self.white, 1)
    #robot sigue avanzando lentamente tambien si ya habia analizado la flecha que sigue estando en el cruce
    elif self.cruce is True and self.flecha_analizada is True:
        self.rangoMax = 0.2
    else:
        self.rangoMax = 0.5

    self.negras_prev = negras
    points.clear()

    # ------------------------------------------------------------------------------------------------------
    #               marcas

    length = len(contListRedMarca)  #conturas de las marcas rojas tomadas antes de suavizar la imagen
    #print("shape1: ", np.shape(contListRedMarca))
    areas = []
    # detectar las marcas rojas solamente cuando no estamos en el cruce
    if (self.cruce is False) and (length >= 1):
        #ya hemos extaido la marca
        #si hay mas objetos rojos, vamos a suponer que la marca será la que tiene la area mas grande de todos
        if length > 1:
            for cnt in contListRedMarca:
                areas.append(cv2.contourArea(cnt))
            index = np.argmax(areas)
            contListRedMarca = contListRedMarca[index]
        else:
            contListRedMarca = contListRedMarca[0]

        #hemos conseguido que tenemos solamente una contura
        if (cv2.contourArea(contListRedMarca) > 1000):
            # comprobar si toda la marca ya se encuentra en la imagen
            for p in self.points_borde_arriba:
                result = cv2.pointPolygonTest(contListRedMarca, p, False)
                #devuelve 0 si el punto esta en la contura y 1 si el punto esta dentro de la contura
                if result == 1 or result == 0:
                    #en este caso la marca todavia no aparece completa en la imagen analizada
                    self.marca_borde_arriba = True
                    break
                else:
                    self.marca_borde_arriba = False
            # comprobar si toda la marca sigue estando en la imagen
            for p in self.points_borde_abajo:
                result = cv2.pointPolygonTest(contListRedMarca, p, False)
                if result == 1 or result == 0:
                    #en este caso una parte de la marca ya habia salido de la imagen analizada
                    self.marca_borde_abajo = True
                    break
                else:
                    self.marca_borde_abajo = False
            #analizamos la marca solo si aparece completa en la imagen
            if (self.marca_borde_arriba is False) and (self.marca_borde_abajo is False):
                #cambiar el tamano de la marca para poder clasificarla
                #en realidad pasamos la imagen original antes de suavizarla
                frame2 = self.normalize_filled(frameMarca, self.red)
                linImgRed = np.all(frame2 == self.red, axis=2).astype(np.uint8) * 255
                contListRed, hierarchy = cv2.findContours(linImgRed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
                # obtener la clase (string) con el nombre del objeto predicho
                cv2.imshow("marca", frame2)
                clase = self.detectar_marca(contListRed[0])
                cv2.drawContours(frame, contListRedMarca, -1, self.white, 2)
                cv2.putText(frame, str(clase), (20, 80),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, self.green, 2)
                print("Marca: ", clase)
        self.marca_borde_abajo = False

    # ---------------------------------------------------------------------------------------------
    #       entrada y salida definitiva

    # dibujar el punto de entrada
    cv2.circle(frame, (entrada[0], entrada[1]), 10, (255, 255, 0), -1)
    # dibujar el punto de salida
    cv2.circle(frame, (salida[0], salida[1]), 10, (0, 255, 255), -1)
    # guardar la salida actual como la salida previa al siguiente frame
    self.salida_prev = salida


    #------------------------------------------------------------------------------------------------------
    #           control


    #calcular el angulo entre el punto de la entrada y salida
    angle = int(math.degrees(math.atan2((entrada[0] - salida[0]), (entrada[1] - salida[1]))))
    #ajustar el angulo a los valores de velocidad (0, 1)
    vel = self.map_vel(angle)
    #ajustar el angulo a los valores de giro (-1, 1)
    pos = self.map_pos(angle)




    # -------------------------------------------------------------------------------------------------------
    #               imprimir informaciones a la imagen


    cv2.putText(frame, "cruce: " + str(self.cruce), (250, 80),
                cv2.FONT_HERSHEY_SIMPLEX, 0.3, self.green, 1)

    cv2.putText(frame, "areas negras: " + str(negras), (20, 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.3, self.green, 1)

    cv2.putText(frame, "Angulo: " + str(angle), (250, 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.3, self.green, 1)

    cv2.putText(frame, "vel: " + str(round(vel, 2)), (250, 40),
                cv2.FONT_HERSHEY_SIMPLEX, 0.3, self.green, 1)

    cv2.putText(frame, "giro: " + str(round(pos, 2)), (250, 60),
                cv2.FONT_HERSHEY_SIMPLEX, 0.3, self.green, 1)


    cv2.imshow("Vision", frame)
    cv2.waitKey(1)
    return self.foundLine, pos, vel
